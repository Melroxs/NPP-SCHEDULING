import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '@/stores/authStore';
import { getTodayAppointments, getWeekAppointments } from '@/services/appointmentService';
import { StatCard } from '@/components/shared/StatCard';
import { AppointmentStatusBadge } from '@/components/shared/AppointmentStatusBadge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar, Clock, CheckCircle, MapPin } from 'lucide-react';
import { formatEST } from '@/lib/timezone';
import type { Appointment } from '@/types/database';

export function TechnicianDashboard() {
  const { profile } = useAuthStore();
  const navigate = useNavigate();
  const [todayAppts, setTodayAppts] = useState<Appointment[]>([]);
  const [weekAppts, setWeekAppts] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile) return;
    const load = async () => {
      try {
        const [today, week] = await Promise.all([
          getTodayAppointments(profile.id),
          getWeekAppointments(profile.id),
        ]);
        setTodayAppts(today);
        setWeekAppts(week);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [profile]);

  if (loading) {
    return <div className="flex justify-center p-8"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" /></div>;
  }

  const completedToday = todayAppts.filter((a) => a.status === 'completed').length;
  const utilization = todayAppts.length > 0 ? Math.round((completedToday / todayAppts.length) * 100) : 0;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Dashboard</h1>

      {/* Google Calendar connection prompt */}
      {profile && !profile.calendar_connected && (
        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="font-medium text-blue-900">Connect Google Calendar</p>
              <p className="text-sm text-blue-700">
                Link your Google Calendar to receive appointment updates directly in your calendar app.
              </p>
            </div>
            <Button variant="outline" onClick={() => navigate('/technician/account')}>
              Connect
            </Button>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Today's Appointments" value={todayAppts.length} icon={Calendar} />
        <StatCard title="This Week" value={weekAppts.length} icon={Clock} />
        <StatCard title="Completed Today" value={completedToday} icon={CheckCircle} />
        <StatCard title="Utilization" value={`${utilization}%`} icon={MapPin} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Today's Schedule</CardTitle>
          </CardHeader>
          <CardContent>
            {todayAppts.length === 0 ? (
              <p className="text-muted-foreground text-sm">No appointments today</p>
            ) : (
              <div className="space-y-3">
                {todayAppts.map((apt) => (
                  <div key={apt.id} className="flex items-center justify-between p-3 rounded-lg border">
                    <div>
                      <p className="font-medium text-sm">
                        {apt.customer?.first_name} {apt.customer?.last_name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {formatEST(apt.start_time, 'h:mm a')} -{' '}
                        {formatEST(apt.end_time, 'h:mm a')}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {apt.address?.address_line}
                      </p>
                    </div>
                    <AppointmentStatusBadge status={apt.status} />
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Upcoming This Week</CardTitle>
          </CardHeader>
          <CardContent>
            {weekAppts.length === 0 ? (
              <p className="text-muted-foreground text-sm">No upcoming appointments</p>
            ) : (
              <div className="space-y-3">
                {weekAppts.slice(0, 8).map((apt) => (
                  <div key={apt.id} className="flex items-center justify-between p-3 rounded-lg border">
                    <div>
                      <p className="font-medium text-sm">
                        {apt.customer?.first_name} {apt.customer?.last_name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {formatEST(apt.start_time, 'EEE, MMM d - h:mm a')}
                      </p>
                    </div>
                    <AppointmentStatusBadge status={apt.status} />
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
